<?php

//Email template constants
const EMP_JOBSITE_APPR = 1;
const INACTIVE = 2;

