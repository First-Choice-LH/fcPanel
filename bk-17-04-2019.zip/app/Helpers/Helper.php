<?php
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\File;
use Illuminate\Pagination\LengthAwarePaginator;

use App\User;

use Illuminate\Support\Facades\Mail;
use App\Mail\PanelEmail;

function sendEmail($user_id, $type){
    $user = User::find($user_id);
    
    if($user && $user->email != ''){
        $message = array(
            'to' => $user->email,
            'type' => $type
        );
        Mail::to($message['to'])->send(new PanelEmail($message));
    }
}

/*function sortArray($array, $request){
    if(!is_array($array)){
        $array = (array) $array;
    }
    $orderby = isset($request['orderby']) ? $request['orderby'] : '';
    $sortby = isset($request['sortby']) ? $request['sortby'] : '';

    if($orderby == '' || $sortby == ''){
        return $array;
    }
    foreach ($array as $k => $v) {
        $sort[$orderby][$k] = $v[$orderby];
    }
    if(count($array) > 0){
        if($sortby == 'asc'){
            array_multisort($sort[$orderby], SORT_ASC, $array);
        }else{
            array_multisort($sort[$orderby], SORT_DESC, $array);
        }
    }
    return $array;
}*/
function sortArray($array, $request){

  $orderby = isset($request['orderby']) ? $request['orderby'] : '';
  $sortby = isset($request['sortby']) ? $request['sortby'] : '';
  if($orderby == '' || $sortby == ''){
      //return $array;
      $new = createObject($array, $request);
      return $new;
  }
  foreach ($array as $k => $v) {
      $sort[$orderby][$k] = $v[$orderby];
  }
  if(count($array) > 0){
      if($sortby == 'asc'){
          array_multisort($sort[$orderby], SORT_ASC, $array);
      }else{
          array_multisort($sort[$orderby], SORT_DESC, $array);
      }
  }
  $array1 = createObject($array, $request);
  return $array1;
}
function createObject($array, $request){

   $page = isset($request->page) ? $request->page : 1;
   $perPage = 5;
   $offset = ($page * $perPage) - $perPage;

   $entries =  new LengthAwarePaginator(
       array_slice($array, $offset, $perPage, true),
       count($array), // Total items
       $perPage, // Items per page
       $page, // Current page
       ['path' => $request->url(), 'query' => $request->query()]
   );
   return $entries;
}
    
