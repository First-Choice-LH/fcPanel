<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;
use Socialite;
use Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    
    public function username(){
        return 'username';
    }
    public function getUsername(Request $request){
       $obj = User::where('email',$request['email'])->first();
       if($obj){
           return response()->json($obj->username);
        }else{
           return response()->json($request['email']);
        }
   }
   public function getUserEmail(Request $request){
       $obj = User::where('username',$request['username'])->first();
       if($obj){
           return response()->json($obj->email);
        }else{
           return '';
        }
   }
    public function socialLogin($social){
        return Socialite::driver($social)->redirect();
    }
  
    public function handleProviderCallback($social){
        $userSocial = Socialite::driver($social)->user();

        $user = User::where(['email' => $userSocial->getEmail()])->first();
        if($user){
            Auth::login($user);
            return redirect('/');
        }else{
            $user  = [
                'name' => $userSocial->getName(),
                'email' => $userSocial->getEmail(),
                'username' => $userSocial->getId(),
                'password' => '',
            ];
            return redirect('/login/callback/after?name='.$user['name'].'&email='.$user['email'].'&username='.$user['username'].'&password='.$user['password']);
        }
    }
}
