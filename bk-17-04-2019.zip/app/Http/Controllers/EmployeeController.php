<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use PDF;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Activity;
use App\RequestJobsite;
use App\User;
use App\Employee;
use Carbon\Carbon;

use App\Repository\Contract\UserInterface as UserInterface;
use App\Repository\Contract\EmployeeInterface as EmployeeInterface;
use App\Repository\Contract\PositionInterface as PositionInterface;
use App\Repository\Contract\ClientInterface as ClientInterface;
use App\Repository\Contract\JobsiteInterface as JobsiteInterface;
use App\Repository\Contract\TimesheetInterface as TimesheetInterface;
use App\Repository\Contract\ImageInterface as ImageInterface;

use App\Http\Requests\EmployeeRequest as EmployeeRequest;

class EmployeeController extends Controller
{
    //
    private $user;
    private $employee;
    private $position;
    private $client;
    private $jobsite;
    private $timesheet;
    private $image;
    private $request;

    public function __construct(Request $request, EmployeeInterface $employee, PositionInterface $position, ClientInterface $client, 
        JobsiteInterface $jobsite, TimesheetInterface $timesheet, UserInterface $user, ImageInterface $image)
    {
        $this->request = $request;
    	$this->user = $user;     
        $this->employee = $employee;
        $this->client = $client;
        $this->jobsite = $jobsite;
        $this->position = $position;
        $this->timesheet = $timesheet;
        $this->image = $image;
    }

    public function dashboard(){
        return view('employees.dashboard');
    }

    public function index(){
        $query = $this->request->input('q');
        $data = array();
        $data['rows'] = $this->employee->sortable($this->request)->paginate(15,$query);        

        return view('employees.list',$data);
    }

    public function create(){
        $data = array();
        $data['clients'] = $this->client->dropdown();
        $data['positions'] = $this->position->dropdown();
        return view('employees.create', $data);
    }

    public function update($id){
        $data = [];
        $data['positions'] = $this->position->dropdown();
        $data['row'] = $this->employee->show($id);
        $emp_id = $this->employee->show($id)->user_id;
        $data['user'] = User::where('id',$emp_id)->first();
        
        return view('employees.create', $data);
    }

    public function save(EmployeeRequest $request)
    {        
        $id = $request->input('id');
        $jobsite_id = $request->input('jobsite_id');

        if($id == null)
        {            
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required',
                'email' => 'required',
                'username' => 'required|string|max:20|unique:users',
                'password' => 'required|string|min:6|confirmed',
            ]);
            if ($validator->fails()) {
               return redirect()->back()->withErrors($validator)->withInput();
            }

            $user_row = [];
            $user_row['name'] = $request->input('first_name');
            $user_row['email'] = $request->input('email');
            $user_row['password'] = Hash::make($request->input('password'));
            $user_row['username'] = $request->input('username');            
            $new_user = $this->user->createWithRole($user_row, 'employee');

            $user_id = $new_user->id;
            $name = '';
        }else{

            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required',
                'email' => 'required'
            ]);
            if ($validator->fails()) {
               return redirect()->back()->withErrors($validator)->withInput();
            }
            $new_user = $this->employee->show($id);
            $user_obj = User::where('id',$new_user->user_id)->first();
            $old_username = $user_obj->username;
            $username = $request->input('username');
            if(!empty($username)){
                if($old_username != $username){
                    $validator = Validator::make($request->all(), [
                        'username' => 'required|string|max:20|unique:users'
                    ]);
                    if ($validator->fails()) {
                       return redirect()->back()->withErrors($validator)->withInput();
                    }
                    $user_row = array();           
                    $user_row['username'] = $username;
                    $this->user->update($user_row, $new_user->user_id);
                }         
            }
            $pass = $request->input('password');
            if(!empty($pass)){  

                $validator = Validator::make($request->all(), [
                    'password' => 'required|string|min:6|confirmed',
                ]);
                if ($validator->fails()) {
                   return redirect()->back()->withErrors($validator)->withInput();
                }

                $user_row = array();           
                $user_row['password'] = Hash::make($pass);
                $this->user->update($user_row, $new_user->user_id);
            }
            $email = $request->input('email');
            if(!empty($email)){            
                $user_row = array();           
                $user_row['email'] = $email;
                $this->user->update($user_row, $new_user->user_id);
            }
            $user_id = $new_user->user_id;
            $name = $new_user->license_image;
        }

        $file = $request->file('license_image');
        if($file != null ){
            $name = strtotime(Carbon::now()).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('/dore/employee'), $name);
        }

        $fields = [
            'first_name',
            'last_name',
            'position_id',
            'phone',
            'email',
            'account_name',
            'account_number',
            'account_bsb',
            'file_number',
            'superannuation',
            'member_number',
            'abn',
            'license_type',
            'license_number',
            'license_date',
            'status'
        ];
        $public = '';
        $insurance = $request->input('insurance');
        if(count($insurance) > 0){
            $public = implode(",",$insurance); 
        }
        

        $employee_row = $request->only($fields);
        $employee_row['user_id'] = $new_user->id;
        $employee_row['license_image'] = $name;
        $employee_row['insurance'] = $public;

        if($id == null){
            $employee_row['user_id'] = $new_user->id;
            $new_employee = $this->employee->create($employee_row);
            $this->employee->attach($new_employee->id, $jobsite_id);

            $activity = new Activity;
            $activity->user_id = $user_id;
            $activity->message = "employee has been created by Admin";
            $activity->save();

        }else{
            $emp = $this->employee->update($employee_row, $id);

            $activity = new Activity;
            $activity->user_id = $user_id;
            $activity->message = "employee profile has been updated by Admin";
            $activity->save();
        }

        return redirect('/employees/');
    }
    public function createEmployee(){
       return view('employees.createEmployee');
    }
    public function myAccount(){
       $data = [];
       $data['row'] = $this->employee->getEmployeeId(Auth::id());
       return view('employees.createEmployee', $data);
    }
    public function saveEmployee(Request $request){

       $id = $request->input('id');
       $jobsite_id = isset($request->jobsite_id) ? $request->jobsite_id : '';

       if($id == null){

            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required',
                'email' => 'required|email',
                'username' => 'required|string|max:20|unique:users',
                'password' => 'required|string|min:6|confirmed',
            ]);
         
            if ($validator->fails()) {
               return redirect()->back()->withErrors($validator)->withInput();
            }

            $user_row = [];
            $user_row['name'] = $request->input('first_name');
            $user_row['email'] = $request->input('email');
            $user_row['password'] = Hash::make($request->input('password'));
            $user_row['username'] = $request->input('username');
            $new_user = $this->user->createWithRole($user_row, 'employee');

            $user_id = $new_user->id;
            
            $name = '';

        }else{
            $validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required',
                'email' => 'required'
            ]);
            if ($validator->fails()) {
               return redirect()->back()->withErrors($validator)->withInput();
            }

            $pass = $request->input('password');
            $new_user = $this->employee->show($id);
            if(!empty($pass)){

                $validator = Validator::make($request->all(), [
                    'password' => 'required|string|min:6|confirmed',
                ]);
                if ($validator->fails()) {
                   return redirect()->back()->withErrors($validator)->withInput();
                }

               $user_row = array();
               $user_row['password'] = Hash::make($pass);
               $this->user->update($user_row, $new_user->user_id);
            }
            $email = $request->input('email');
            if(!empty($email)){            
                $user_row = array();           
                $user_row['email'] = $email;
                $this->user->update($user_row, $new_user->user_id);
            }
            $user_id = $new_user->user_id;
            $name = $new_user->license_image;
       }

        $file = $request->file('license_image');
        if($file != null ){
            $name = strtotime(Carbon::now()).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('/dore/employee'), $name);
        }

        $fields = [
            'first_name',
            'last_name',
            'position_id',
            'phone',
            'email',
            'account_name',
            'account_number',
            'account_bsb',
            'file_number',
            'superannuation',
            'member_number',
            'abn',
            'license_type',
            'license_number',
            'license_date',
            'status'
        ];
        $public = '';
        $insurance = $request->input('insurance');
        if(count($insurance) > 0){
            $public = implode(",",$insurance); 
        }

        $employee_row = $request->only($fields);
        $employee_row['license_image'] = $name;
        $employee_row['insurance'] = $public;
      
       if($id == null){
            $employee_row['user_id'] = $user_id;
            $new_employee = $this->employee->create($employee_row);
            if($jobsite_id != ''){
                $this->employee->attach($new_employee->id, $jobsite_id);
            }
            $activity = new Activity;
            $activity->user_id = $new_user->id;
            $activity->message = "employee has joined";
            $activity->save();

            return redirect('login');
       }else{
            $this->employee->update($employee_row, $id);

            $activity = new Activity;
            $activity->user_id = $user_id;
            $activity->message = "employee has updated profile";
            $activity->save();

           return redirect()->back()->withSuccess("Data successfully updated");
       }
       
   }
    public function remove_image(Request $request)
    {
        $id=$request['id'];
        $data=$this->employee->show($id);
        $row = array();     
        unlink(public_path('/dore/employee/'.$data->license_image));  
        $row['license_image'] = "";
        $this->employee->update($row,$data->id);
        return redirect('/employees/');
    }

    public function jobsite($id)
    {
        $employee_id = $id;

        $data = [];
        $data['employee_id'] = $employee_id;
        $data['rows'] = $this->employee->paginateByEmployee($employee_id);
        return view('employees.jobsite', $data);
    }

    public function jobsites()
    {
        $employee = $this->employee->getEmployeeId(Auth::id());
        // echo "<pre>";print_r(Auth::id());die;
        $employee_id = (!empty($employee->id)) ? $employee->id : 0;
        
        $data = [];
        $data['employee_id'] = $employee_id;
        $data['rows'] = $this->employee->paginateByEmployee($employee_id);
        return view('employees.jobsites', $data);
    }

    public function timesheet($jobsite_id=0,$client_id=0)
    {
        $employee = $this->employee->getEmployeeId(Auth::id());
        $employee_id = $employee->id;

        $data = [];

        $data['client_id'] = $client_id;
        $data['jobsite_id'] = $jobsite_id;
        $data['employee_id'] = $employee_id;

        $date = $this->request->get('date');
        
        if(!empty($date)){
            $dayStart = new \DateTime($date);

            if($dayStart->format("D") != "Mon"){               
                $dayStart->modify("last monday");
            }

        }else{
            $dayStart = new \DateTime("last monday");
        }

        $baseDate = $dayStart->format("Y-m-d");
        $previousWeek = new \DateTime($baseDate);
        $previousWeek->modify("previous monday");
        $nextWeek = new \DateTime($baseDate);
        $nextWeek->modify("next monday");

        $data['previousWeek'] = url('/employees/jobsites/timesheet/'.$jobsite_id.'/'.$client_id.'/?date='.$previousWeek->format("Y-m-d"));
        $data['nextWeek'] = url('/employees/jobsites/timesheet/'.$jobsite_id.'/'.$client_id.'/?date='.$nextWeek->format("Y-m-d"));

        $data['jobsite'] = $this->jobsite->show($jobsite_id);
        $data['employee'] = $this->employee->show($employee_id);
        $data['week'] = [];
        $day = 0;
        
        while($day < 7){
            $tempDay = new \DateTime($dayStart->format("Y-m-d"));
            $tempDay->modify("+".$day." day");
            
            $data['week'][] = $tempDay;
            $data['rows'][] = $this->timesheet->getByDate($employee_id, $jobsite_id, $tempDay);
            $day++;
        }

        $time = [];
        $start_hour = 0;
        $end_hour = 24;

        $data['default_start'] = '07:00:00';
        $data['default_end'] = '15:30:00';

        for($i=$start_hour;$i<=$end_hour;$i++)
        {
            if($i != $end_hour){
                // hour
                if($i > 12){
                    $temp_hour = str_pad($i-12, 2, '0', STR_PAD_LEFT);
                }else{
                    $temp_hour = str_pad($i, 2, '0', STR_PAD_LEFT);
                }
            }

            for($j=0;$j<60;$j+=15){
                
                $temp_min =  str_pad($j, 2, '0', STR_PAD_LEFT);

                if($i != $end_hour && $j <= 30)
                {
                    if($i < 12)
                    {
                        $temp_suffix = 'AM';
                    }else{
                        $temp_suffix = 'PM';
                    }
                    
                    $time[]['key'] = $temp_hour.':'.$temp_min.' '.$temp_suffix;
                    $time[count($time)-1]['value'] = str_pad($i, 2, '0', STR_PAD_LEFT).':'.$temp_min.':00';
                }
            }
        }

        $data['times'] = $time;
        if(!empty($data['rows'][6]->images)){
            $data['images'] = $data['rows'][6]->images()->get();
        }else{
            $data['images'] = [];
        }

        $agent = new Agent();
        
        if($agent->isMobile()){
            $data['is_mobile'] = true;
            return view('employees.mobile.timesheet', $data);
        }else{
            $data['is_mobile'] = false;
            return view('employees.timesheet', $data);
        }
    }

    public function timesheet_save()
    {
        $employee = $this->employee->getEmployeeId(Auth::id());
        $employee_id = $employee->id;

        $export_pdf = $this->request->input('export_pdf');           
        $download_mode = $this->request->input('download_mode');

        $client_id = $this->request->input('client_id');
        $jobsite_id = $this->request->input('jobsite_id');
        
        $ids = $this->request->input('id');
        $dates = $this->request->input('date');
        $starts = $this->request->input('start');
        $ends = $this->request->input('end');
        $break = $this->request->input('break');
        $status = $this->request->input('status');
        
        for($i=0; $i< sizeof($ids); $i++)
        {
            // if date is empty don't proceed
            if(empty($starts[$i]) || empty($ends[$i])) continue;
            
            $row = [];
            $id = $ids[$i];
            $row['date'] = $dates[$i];
            $row['employee_id'] = intval($employee_id);
            $row['jobsite_id'] = intval($jobsite_id);
            $start = new \DateTime($dates[$i]);
            $start->modify($starts[$i]);
            $row['start'] = $start->format("Y-m-d H:i:s");
            $end = new \DateTime($dates[$i]);
            $end->modify($ends[$i]);
            $row['end'] = $end->format("Y-m-d H:i:s");
            $row['break'] = $break[$i];
            $row['status'] = $status[$i];
            

            if($id == null)
            {
                $id = $this->timesheet->create($row);                
            }else{
                $this->timesheet->update($row,$id);
            }

            // store images against last days entry
            if($i == 6 && !is_null($this->request->timesheetfile)){
                $filename = $this->request->timesheetfile->store('public');
               
                if(isset($filename)){                
                    if(is_object($id))
                    {
                        $timesheet_id = $id->id;
                    }else{
                        $timesheet_id = $id;
                    }
                    $this->image->create(['timesheet_id' => $timesheet_id, 'imagename' => $filename]);
                }
            }

        }

        if($export_pdf == 1)
        {
            for($i=0; $i< sizeof($ids); $i++)
            {
                $tempDay = new \DateTime($dates[$i]);               
                $rows[] = $this->timesheet->getByDate($employee_id, $jobsite_id, $tempDay);
            }      

            $columns = ['Date', 'Start Time', 'End Time', 'Break', 'Status'];

            $content = implode(',',$columns)."\r\n";

            $frows = array();
            foreach($rows as $row) {
                $row_date = Date('d/m/Y', strtotime($row->date));
                $row_start = Date('H:i:s', strtotime($row->start));
                $row_end = Date('H:i:s', strtotime($row->end));
                $row_break = $row->break.' min(s)';                
                
                $row_status = ($row->status == 1) ? 'Approved' : 'Unapproved'; 

                $frows[] = [$row_date, $row_start, $row_end, $row_break, $row_status];

                $content .= implode(',',[$row_date, $row_start, $row_end, $row_break, $row_status])."\r\n";
            }

            if($download_mode == 'pdf'){
                view()->share('rows', $frows);
                
                PDF::setOptions(['dpi' => 150, 'orientation' => 'landscape', 'defaultFont' => 'sans-serif']);

                $pdf = PDF::loadView('pdf');

                return $pdf->download('timesheet.pdf');
            }

            Storage::disk('local')->put('timesheet.csv', $content);

            return Storage::download('timesheet.csv'); 
        }

        $activity = new Activity;
        $activity->user_id = $employee->user_id;
        $activity->message = "employee has added a timesheet";
        $activity->save();

        return redirect('/employees/jobsites/timesheet/thankyou')->with('from',$dates[0])->with('to',$dates[sizeof($dates)-1]);

    }

    public function assign($id=0)
    {
        $data = [];
        $data['employee_id'] = $id;

        $data['clients'] = $this->client->dropdown();
        
        return view('employees.assign', $data);
    }

    public function assign_save(Request $request)
    {
        $employee_id = $request->input('employee_id');
        $client_id = $request->input('client_id');
        $jobsite_id = $request->input('jobsite_id');
        
        //dd($this->employee->show($employee_id));

        $this->employee->attach($employee_id, $jobsite_id);

        return redirect('/employees/jobsite/'.$employee_id);
    }

    public function unassign($employee_id, $jobsite_id)
    {
        $this->employee->detach($employee_id, $jobsite_id);        
        
        return redirect('/employees/jobsite/'.$employee_id);
    }

    public function thankyou(Request $request)
    {
        $data = [];
        $data['start'] = new \DateTime($request->session()->get('from'));
        $data['end'] = new \DateTime($request->session()->get('to'));

        return view('employees.thankyou', $data);
    }
    public function jobsiteRequest(){
       $data = array();
       $data['clients'] = $this->client->dropdown();
       $data['positions'] = $this->position->dropdown();
       return view('employees.request_jobsite',$data);
   }

    public function addRequest(Request $request){
        $validator = Validator::make($request->all(), [
           'company' => 'required',
           'jobsite' => 'required',
           'position' => 'required',
       ]);

       if ($validator->fails()){
           return redirect()->back()->withErrors($validator);
       }

       $reqjobsite = new RequestJobsite;
       $reqjobsite->user_id = Auth::id();
       $reqjobsite->client_id = $request->company;
       $reqjobsite->jobsite_id = $request->jobsite;
       $reqjobsite->position_id = $request->position;
       $reqjobsite->status = $request->status;
       $reqjobsite->save();

       $activity = new Activity;
       $activity->user_id = Auth::id();
       $activity->message = "employee has requested for jobsite.";
       $activity->save();

       return view('employees.message');
   }

   public function getJobsite($id){
       $emp = $this->employee->getEmployeeId(Auth::id());
       $jobsites_emp = $emp->jobsites;
       $jobsites_client = $this->jobsite->byClientId($id);
       $data = [];

        foreach ($jobsites_emp as $key => $value) {
           if($value->client_id == $id){
               $data[] = $value;
           }
        }
       return response()->json($data);
   }

   public function timesheetList(Request $request){

       $client_id = isset($request->client_id) ? $request->client_id : '';
       $jobsite_id = isset($request->jobsite_id) ? $request->jobsite_id : '';

       $date = isset($request->date) ? $request->date : '';

       $emp = $this->employee->getEmployeeId(Auth::id());
       $jobsites = $emp->jobsites;

       $timesheet = $emp->timesheets->where('status',1);

       if($client_id != ''){
           $jobsite_ids = $this->jobsite->byClientId($client_id)->pluck('id');
           $timesheet = $timesheet->whereIn('jobsite_id',$jobsite_ids);
       }
       if($jobsite_id != ''){
           $timesheet = $timesheet->where('jobsite_id',$jobsite_id);
       }
       if($date != ''){
           $date = date('Y-m-d', strtotime($date));
           $timesheet = $timesheet->where('date',$date);
       }

       $id = array();
       $client = [];
       foreach ($jobsites as $key => $value) {

           if(!in_array($value->client->id, $id)){
               $client[] = $value->client;
               $id[] = $value->client->id;
           }
       }
       /*start*/
       $data = [];
          $final = [];
          foreach ($timesheet as $key => $value) {
              $temp = [];
              $temp['id'] = $value->id;
              $temp['title'] = $value->jobsite->title;
              $temp['date'] = $value->date;
              $temp['start'] = $value->start;
              $temp['end'] = $value->end;
              $final[] = $temp;
          }
           $final_array = sortArray($final, $request);
          return view('employees.timesheetlist',array('clients'=>$client,'timesheet'=>$final_array));
        //return view('employees.timesheetlist',array('clients'=>$client,'timesheet'=>$timesheet));
   }
   public function saveEmployeeAfterSocial(Request $request){

        $user = [
            'name' => $request['name'],
            'email' => $request['email'],
            'username' => $request['username'],
            'password' => '',
        ];

        $new_user = $this->user->createWithRole($user, 'employee');

        $employee_row['user_id'] = $new_user->id;
        $employee_row['first_name'] = $user['name'];
        $employee_row['email'] = $user['email'];
        $employee_row['status'] = 0;
       
        $new_employee = $this->employee->create($employee_row);

        $activity = new Activity;
        $activity->user_id = $new_user->id;
        $activity->message = "employee has joined";
        $activity->save();

        Auth::login($new_user);

        return redirect('/');
       
       
   }
    
}
