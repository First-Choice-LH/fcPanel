<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repository\Contract\JobsiteInterface as JobsiteInterface;
use App\Repository\Contract\ClientInterface as ClientInterface;
use App\Http\Requests\JobsiteRequest as JobsiteRequest;
use App\Repository\Contract\EmployeeInterface as EmployeeInterface;
use App\Repository\Contract\SupervisorInterface as SupervisorInterface;

use App\RequestJobsite;
use App\Activity;
class JobsiteController extends Controller
{
    //
	private $jobsite;
    private $client;
    private $employee;
    private $supervisor;

    public function __construct(JobsiteInterface $jobsite, ClientInterface $client, EmployeeInterface $employee, SupervisorInterface $supervisor)
    {
        $this->jobsite = $jobsite;
        $this->client = $client;
        $this->supervisor = $supervisor;
        $this->employee = $employee;
    }

    public function index(Request $request)
    {
        $data = array();
        $data['rows'] = $this->jobsite->sortable($request)->paginate();
        return view('jobsites.list',$data);
    }

    public function create()
    {
        $data = [];
        $data['clients'] = $this->client->dropdown();

        return view('jobsites.create', $data);
    }

    public function update($id)
    {
        $data = [];
        $data['clients'] = $this->client->dropdown();
        $data['row'] = $this->jobsite->show($id);
        
        return view('jobsites.create', $data);
    }

    public function save(JobsiteRequest $request)
    {
        $id = $request->input('id');

        $fields = [
            'client_id',
            'title',
            'address',
            'suburb',
            'state',
            'country',
            'postcode',
            'status'
        ];

        if($id == null){
            $this->jobsite->create($request->only($fields));
        }else{
            $this->jobsite->update($request->only($fields),$id);
        }

        return redirect('/jobsites/');
    }

   public function pendingRequest()
   {
       $data = RequestJobsite::orderBy('id','desc')->paginate(10);
       return view('dashboard.pendingRequest',array('data'=>$data));
   }
    public function approveRequest(Request $request){

        if($request->action == 1){

            $approve = RequestJobsite::where('id',$request->id)->first();
            $approve->status = 1;
            $approve->save();

            $user_id = $approve->user_id;
            $supervisor = $this->supervisor->getSupervisorId($user_id);
            if($supervisor){
                $this->supervisor->attach($supervisor->id, $approve->jobsite_id);
            }
            
            $employee = $this->employee->getEmployeeId($user_id);
            if($employee){
                $this->employee->attach($employee->id, $approve->jobsite_id);
            }

            $activity = new Activity;
            $activity->user_id = $approve->user_id;
            $activity->message = "admin has approved jobsite request ".$approve->jobsite->title;
            $activity->save();

            sendEmail($approve->user_id,EMP_JOBSITE_APPR);
       }else{
            $approve = RequestJobsite::where('id',$request->id)->first();

            $activity = new Activity;
            $activity->user_id = $approve->user_id;
            $activity->message = "admin has removed jobsite request ".$approve->jobsite->title;
            $activity->save();

            $approve->delete();

       }
       return redirect()->action('JobsiteController@pendingRequest');

   }
}
