<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use PDF;
use Jenssegers\Agent\Agent;
use App\Activity;
use App\User;
use Illuminate\Support\Facades\Validator;
use App\RequestJobsite;
use App\Supervisor;
use App\Timesheet;
use App\Employee;
use App\Repository\Contract\UserInterface as UserInterface;
use App\Repository\Contract\EmployeeInterface as EmployeeInterface;
use App\Repository\Contract\SupervisorInterface as SupervisorInterface;
use App\Repository\Contract\ClientInterface as ClientInterface;
use App\Repository\Contract\JobsiteInterface as JobsiteInterface;
use App\Repository\Contract\TimesheetInterface as TimesheetInterface;
use App\Repository\Contract\PositionInterface as PositionInterface;
use App\Repository\Contract\ImageInterface as ImageInterface;

use App\Http\Requests\SupervisorRequest as SupervisorRequest;

class SupervisorController extends Controller
{
    //
    private $user;
    private $supervisor;
    private $employee;
    private $client;
    private $jobsite;
    private $timesheet;
    private $position;
    private $request;

    public function __construct(Request $request, EmployeeInterface $employee, SupervisorInterface $supervisor, ClientInterface $client, 
        JobsiteInterface $jobsite, TimesheetInterface $timesheet, PositionInterface $position, UserInterface $user, ImageInterface $image)
    {
        $this->request = $request;
    	$this->user = $user;     
        $this->supervisor = $supervisor;
        $this->employee = $employee;
        $this->client = $client;
        $this->jobsite = $jobsite;
        $this->position = $position;
        $this->image = $image;
        $this->timesheet = $timesheet;
    }

    public function dashboard(){
        return view('supervisors.dashboard');
    }
    public function activity($client_id=0, $jobsite_id=0){
        $supervisor_tms = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor_tms->id;
        $ids = [];
        $jobsites = $this->supervisor->paginateBySupervisor($supervisor_id);
        foreach ($jobsites as $tms1){
            $emplo = $this->supervisor->getEmployeeByJobsite($supervisor_id, $tms1);
            foreach ($emplo as $emp){
                $ids[] = $emp->user_id;
            }
        }
        
        $acts = Activity::whereIn('user_id',$ids)->orderBy('id','desc')->paginate(15);
        return view('dashboard.activity',array('user'=>$acts));
    }

    public function index()
    {
        $data = array();
        $data['rows'] = $this->supervisor->sortable($this->request)->paginate();
        return view('supervisors.list',$data);
    }

    public function create()
    {
        $data = array();
        $data['clients'] = $this->client->dropdown();
        return view('supervisors.create', $data);
    }

    public function update($id)
    {
        $data = [];
        $data['clients'] = $this->client->dropdown();
        $data['row'] = $this->supervisor->show($id);
        
        return view('supervisors.create', $data);
    }

    public function save(SupervisorRequest $request)
    {        
        $id = $request->input('id');
        $jobsite_id = $request->input('jobsite_id');

        if($id == null)
        {            
            $user_row = [];
            $user_row['name'] = $request->input('first_name');
            $user_row['password'] = Hash::make($request->input('password'));
            $user_row['username'] = $request->input('username');      
            $user_row['email'] = $request->input('email');      
            $new_user = $this->user->createWithRole($user_row, 'supervisor');

            $user_id = $new_user->id;
        }else{
            $pass = $request->input('password');
            $new_user = $this->supervisor->show($id); 
            if(!empty($pass)){            
                $user_row = array();           
                $user_row['password'] = Hash::make($pass);
                $this->user->update($user_row, $new_user->user_id);
            }
            $email = $request->input('email');
            if(!empty($email)){            
                $user_row = array();           
                $user_row['email'] = $email;
                $this->user->update($user_row, $new_user->user_id);
            }

            $user_id = $new_user->user_id;
        }

        $fields = [
            'first_name',
            'last_name',
            'phone',
            'email',
            'client_id',
            'status'
        ];
        
        $supervisor_row = $request->only($fields);
        $supervisor_row['user_id'] = $new_user->id;

        if($id == null){
            $new_supervisor = $this->supervisor->create($supervisor_row);
            $this->supervisor->attach($new_supervisor->id, $jobsite_id);

            $activity = new Activity;
            $activity->user_id = $user_id;
            $activity->message = "supervisor has been created by Admin";
            $activity->save();

        }else{
            unset($supervisor_row['user_id']);
            $this->supervisor->update($supervisor_row, $id);

            $activity = new Activity;
            $activity->user_id = $user_id;
            $activity->message = "supervisor profile has been updated by Admin";
            $activity->save();

        }

        return redirect('/supervisors/');
    }

    public function jobsite($id)
    {
        $supervisor_id = $id;

        $data = [];
        $data['supervisor_id'] = $supervisor_id;
        $data['rows'] = $this->supervisor->paginateBySupervisor($supervisor_id);
        return view('supervisors.jobsite', $data);
    }

    public function jobsites(Request $request)
    {
        $supervisor = $this->supervisor->getSupervisorId(Auth::id());        
        $supervisor_id = $supervisor->id;

        $data = [];
        $data['supervisor_id'] = $supervisor_id;
       // $data['rows'] = $this->supervisor->paginateBySupervisor($supervisor_id);
        $rows = $this->supervisor->paginateBySupervisor($supervisor_id);
       foreach ($rows as $key => $value) {
          $temp = [];
          $temp['id'] = $value->id;
          $temp['title'] = $value->title;
          $temp['company_name'] = $value->client->company_name;
          $temp['client_id'] = $value->client_id;
          $final[] = $temp;
      }

        $data['rows'] = sortArray($final, $request);
        return view('supervisors.jobsites', $data);
    }

    public function employees($client_id=0, $jobsite_id=0,Request $request)
    {
        $supervisor = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor->id;
        $final = [];
        $data = [];
        $data['jobsite_id'] = $jobsite_id;
        $data['client_id'] = $client_id;
        $data['supervisor_id'] = $supervisor_id;
        $rows = $this->supervisor->getEmployeeByJobsite($supervisor_id, $jobsite_id);
        foreach ($rows as $key => $value) {
           $temp = [];
           $temp['id'] = $value->id;
           $temp['first_name'] = $value->first_name;
           $temp['last_name'] = $value->last_name;
           $temp['phone'] = $value->phone;
           $temp['client'] = $value->jobsites->first()->client_id;

           $final[] = $temp;
       }

       $data['rows'] = sortArray($final, $request);
       return view('supervisors.employees', $data);
       //return view('supervisors.employees', $data);
    }

    public function timesheet($client_id=0, $jobsite_id=0, $employee_id=0)
    {
        $supervisor = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor->id;

        $data = [];

        $data['client_id'] = $client_id;
        $data['jobsite_id'] = $jobsite_id;
        $data['employee_id'] = $employee_id;

        $date = $this->request->get('date');
        
        if(!empty($date)){
            $dayStart = new \DateTime($date);
            if($dayStart->format("D") != "Mon"){               
                $dayStart->modify("previous monday");
            }
        }else{
            $dayStart = new \DateTime("last monday");
        }

        $baseDate = $dayStart->format("Y-m-d");
        $previousWeek = new \DateTime($baseDate);
        $previousWeek->modify("previous monday");
        $nextWeek = new \DateTime($baseDate);
        $nextWeek->modify("next monday");

        $data['previousWeek'] = url('/supervisors/jobsites/employees/timesheet/'.$client_id.'/'.$jobsite_id.'/'.$employee_id.'/?date='.$previousWeek->format("Y-m-d"));
        $data['nextWeek'] = url('/supervisors/jobsites/employees/timesheet/'.$client_id.'/'.$jobsite_id.'/'.$employee_id.'/?date='.$nextWeek->format("Y-m-d"));

        $data['jobsite'] = $this->jobsite->show($jobsite_id);
        $data['employee'] = $this->employee->show($employee_id);
        $data['week'] = [];
        $day = 0;
        
        while($day < 7){
            $tempDay = new \DateTime($dayStart->format("Y-m-d"));
            $tempDay->modify("+".$day." day");
            
            $data['week'][] = $tempDay;
            $data['rows'][] = $this->timesheet->getByDate($employee_id, $jobsite_id, $tempDay);
            $day++;
        }

        $time = [];
        $start_hour = 7;
        $end_hour = 16;
        $data['start'] =  $start_hour.":00:00";
        $data['end'] =  $end_hour.":00:00";

        $data['default_start'] = '07:00:00';
        $data['default_end'] = '15:30:00';

        for($i=$start_hour;$i<=$end_hour;$i++)
        {
            if($i != $end_hour){
                // hour
                if($i > 12){
                    $temp_hour = str_pad($i-12, 2, '0', STR_PAD_LEFT);
                }else{
                    $temp_hour = str_pad($i, 2, '0', STR_PAD_LEFT);
                }
            }

            for($j=0;$j<60;$j+=15){
                
                $temp_min =  str_pad($j, 2, '0', STR_PAD_LEFT);

                if($i != $end_hour && $j <= 30)
                {
                    if($i < 12)
                    {
                        $temp_suffix = 'AM';
                    }else{
                        $temp_suffix = 'PM';
                    }
                    
                    $time[]['key'] = $temp_hour.':'.$temp_min.' '.$temp_suffix;
                    $time[count($time)-1]['value'] = str_pad($i, 2, '0', STR_PAD_LEFT).':'.$temp_min.':00';
                }
            }
        }

        $data['times'] = $time;
        if(!empty($data['rows'][6]->images)){
            $data['images'] = $data['rows'][6]->images()->get();
        }else{
            $data['images'] = [];
        }
        
        $agent = new Agent();
        
        if($agent->isMobile()){
            $data['is_mobile'] = true;
            return view('supervisors.mobile.etimesheet', $data);
        }else{
            $data['is_mobile'] = false;
            return view('supervisors.etimesheet', $data);
        }

        //return view('supervisors.timesheet', $data);
    }

    public function timesheet_save()
    {
        $supervisor = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor->id;

        $export_pdf = $this->request->input('export_pdf');           
        $download_mode = $this->request->input('download_mode');

        $employee_id = $this->request->input('employee_id');
        $client_id = $this->request->input('client_id');
        $jobsite_id = $this->request->input('jobsite_id');
        
        $ids = $this->request->input('id');
        $dates = $this->request->input('date');
        $starts = $this->request->input('start');
        $ends = $this->request->input('end');
        $break = $this->request->input('break');
        $status = $this->request->input('status');
        
        for($i=0; $i < sizeof($ids); $i++)
        {
            // if date is empty don't proceed
            if(empty($starts[$i]) || empty($ends[$i])) continue;
            
            $row = [];
            $id = $ids[$i];
            $row['date'] = $dates[$i];
            $row['employee_id'] = intval($employee_id);
            $row['jobsite_id'] = intval($jobsite_id);
            $start = new \DateTime($dates[$i]);
            $start->modify($starts[$i]);
            $row['start'] = $start->format("Y-m-d H:i:s");
            $end = new \DateTime($dates[$i]);
            $end->modify($ends[$i]);
            $row['end'] = $end->format("Y-m-d H:i:s");
            $row['break'] = $break[$i];
            $row['status'] = $status[$i];
            
            if($id == null)
            {
                $id = $this->timesheet->create($row);
            }else{
                $this->timesheet->update($row,$id);
            }
            
            // store images against last days entry
            if($i == 6 && !is_null($this->request->timesheetfile)){
                $filename = $this->request->timesheetfile->store('public');
               
                if(isset($filename)){                
                    if(is_object($id))
                    {
                        $timesheet_id = $id->id;
                    }else{
                        $timesheet_id = $id;
                    }
                    $this->image->create(['timesheet_id' => $timesheet_id, 'imagename' => $filename]);
                }
            }
        }

        if($export_pdf == 1)
        {
            for($i=0; $i< sizeof($ids); $i++)
            {
                $tempDay = new \DateTime($dates[$i]);               
                $rows[] = $this->timesheet->getByDate($employee_id, $jobsite_id, $tempDay);
            }      

            $columns = ['Date', 'Start Time', 'End Time', 'Break', 'Status'];

            $content = implode(',',$columns)."\r\n";

            $frows = array();

            foreach($rows as $row) {
                $row_date = Date('d/m/Y', strtotime($row->date));
                $row_start = Date('H:i:s', strtotime($row->start));
                $row_end = Date('H:i:s', strtotime($row->end));
                $row_break = $row->break.' min(s)';                
                
                $row_status = ($row->status == 1) ? 'Approved' : 'Unapproved'; 

                $frows[] = [$row_date, $row_start, $row_end, $row_break, $row_status];

                $content .= implode(',',[$row_date, $row_start, $row_end, $row_break, $row_status])."\r\n";
            }

            if($download_mode == 'pdf'){
                view()->share('rows', $frows);
                
                PDF::setOptions(['dpi' => 150, 'orientation' => 'landscape', 'defaultFont' => 'sans-serif']);

                $pdf = PDF::loadView('pdf');

                return $pdf->download('timesheet.pdf');
            }

            Storage::disk('local')->put('timesheet.csv', $content);

            return Storage::download('timesheet.csv'); 
        }

        return redirect('/supervisors/jobsites/employees/timesheet/thankyou')->with('from',$dates[0])->with('to',$dates[sizeof($dates)-1]);
        //return redirect('/supervisors/jobsites/employees/'.$client_id.'/'.$jobsite_id);

    }

    public function assign($id=0)
    {
        $data = [];
        $data['supervisor_id'] = $id;

        //$data['jobsites'] = $this->supervisor->dropdownJobsite($id);
        $client_id = Supervisor::where('id',$id)->value('client_id');
        $data['jobsites'] = $this->jobsite->byClientId($client_id);
        
        return view('supervisors.assign', $data);
    }

    public function assign_save(Request $request)
    {
        $supervisor_id = $request->input('supervisor_id');
        $client_id = $request->input('client_id');
        $jobsite_id = $request->input('jobsite_id');
        
        $this->supervisor->attach($supervisor_id, $jobsite_id);

        return redirect('/supervisors/jobsite/'.$supervisor_id);
    }

    public function unassign($supervisor_id, $jobsite_id)
    {
        $this->supervisor->detach($supervisor_id, $jobsite_id);        
        
        return redirect('/supervisors/jobsite/'.$supervisor_id);
    }

    public function thankyou(Request $request)
    {
        $data = [];
        $data['start'] = new \DateTime();//new \DateTime($request->session()->get('from'));
        $data['end'] = new \DateTime();//new \DateTime($request->session()->get('to'));

        return view('supervisors.thankyou', $data);
    }
     
    public function employee($client_id=0, $jobsite_id=0,Request $request){

       $supervisor_emp = $this->supervisor->getSupervisorId(Auth::id());
       $supervisor_id = $supervisor_emp->id;

       $emp = [];
       $employee = [];
       $jobsites = $this->supervisor->paginateBySupervisor($supervisor_id);
       foreach ($jobsites as $emp1)
       {
           $temp1 = $this->supervisor->getEmployeeByJobsite($supervisor_id, $emp1);
           $temp = $temp1->toArray();
           foreach ($temp['data'] as $te){
               $te['jobsite'] = $emp1->title;
               $employee[] = $te;
           }
       }
       /*start*/
       $rows = $employee;
          foreach ($rows as $key => $value) {

             $temp = [];
             $temp['id'] = $value['id'];
             $temp['first_name'] = $value['first_name'];
             $temp['last_name'] = $value['last_name'];
             $temp['phone'] = $value['phone'];
             $temp['jobsite'] = $value['jobsite'];
             $final[] = $temp;
         }

        $data['rows'] = sortArray($final, $request);
         return view('supervisors.employee', $data);
      //return view('supervisors.employee', array('employee'=>$employee));
   }
    public function employeeTimesheet(Request $request){
        $search = isset($request['employee']) ? $request['employee'] : '';

        if($search != ''){
           $employee = Employee::where('first_name', 'like', '%'.$search.'%')->orWhere('last_name', 'like', '%'.$search.'%')->pluck('id')->toArray();
        }

        $supervisor_tms = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor_tms->id;
        $ids = [];$final = [];
        $jobsites = $this->supervisor->paginateBySupervisor($supervisor_id);

        foreach ($jobsites as $tms1){
            $emplo = $this->supervisor->getEmployeeByJobsite($supervisor_id, $tms1);
               foreach ($emplo as $emp){
                   $ids[] = $emp->id;
               }
        }
        if(isset($employee)){
           $result = array_intersect($employee, $ids);
           $timesheets = $this->timesheet->getTimesheetByEmployeeIds($result);
           return view('supervisors.timesheets', array('timesheet'=>$timesheets));
        }
        $rows = $this->timesheet->getTimesheetByEmployeeIds($ids);
          foreach($rows as $key=>$value)
        {
          $temp = [];
          $temp['id']=$value->id;
          $temp['first_name'] = $value->employee->first_name;
          $temp['date'] = $value->date;
          $temp['start'] = $value->start;
          $temp['end'] = $value->end;
          $final[]=$temp;
        }
        $timesheets['rows'] = sortArray($final, $request);
       return view('supervisors.timesheets', $timesheets);
     }
    public function myaccount(Request $request){
       $Record_get  = $this->supervisor->getSupervisorId(Auth::id());
       $uname_get = User::where('email', $Record_get->email)->first();
       return view('supervisors.myaccount', ['Record_get' => $Record_get, 'uname_get' => $uname_get]);
   }

   public function Update1(Request $request)
   {

        $validator = Validator::make($request->all(), [
            'first_name' => 'required',
            'last_name' => 'required',
            'phone' => 'required',
            'email' => 'required|email',
       ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

       $id = $request->id;
       $new_user = $this->supervisor->show($id);

        if($id != null){
            $email = $request->input('email');
            if(!empty($email)){
                $user_row = array();
                $user_row['email'] = $email;
                $this->user->update($user_row, $new_user->user_id);
            }

            $pass = $request->input('password');
            if(!empty($pass)){

                $validator = Validator::make($request->all(), [
                    'password' => 'required|string|min:6|confirmed',
                ]);
                if ($validator->fails()) {
                   return redirect()->back()->withErrors($validator)->withInput();
                }

                $user_row = array();
                $user_row['password'] = Hash::make($pass);
                $this->user->update($user_row, $new_user->user_id);
            }

            $fields = [
               'first_name',
               'last_name',
               'phone',
               'email',
            ];

           $supervisor_row = $request->only($fields);
           $this->supervisor->update($supervisor_row, $id);

           $activity = new Activity;
           $activity->user_id = $new_user->user_id;
           $activity->message = "supervisor has updated profile";
           $activity->save();
        }
        else{
            $message = "Something Went Wrong";
        }
       return back();
   }
   public function jobsiteRequest(){
       $data = array();
       $data['clients'] = $this->client->dropdown();
       return view('supervisors.request_jobsite',$data);
   }
    public function addRequest(Request $request){
        $validator = Validator::make($request->all(), [
           'company' => 'required',
           'jobsite' => 'required'
       ]);

       if ($validator->fails()){
           return redirect()->back()->withErrors($validator);
       }

       $reqjobsite = new RequestJobsite;
       $reqjobsite->user_id = Auth::id();
       $reqjobsite->client_id = $request->company;
       $reqjobsite->jobsite_id = $request->jobsite;
       $reqjobsite->status = $request->status;
       $reqjobsite->save();

       $activity = new Activity;
       $activity->user_id = Auth::id();
       $activity->message = "supervisor has requested for jobsite.";
       $activity->save();

       return view('supervisors.message');
   }
    public function sup_pending_req(Request $request){
        $supervisor = $this->supervisor->getSupervisorId(Auth::id());
        $supervisor_id = $supervisor->id;
        $ids = [];$final = [];
        $jobsites = $this->supervisor->paginateBySupervisor($supervisor_id);

        foreach ($jobsites as $tms1){
            $emplo = $this->supervisor->getEmployeeByJobsite($supervisor_id, $tms1);
            foreach ($emplo as $emp){
               $ids[] = $emp->id;
            }
        }
        $rows = $this->timesheet->getPendingTimesheetByEmployeeIds($ids);
          foreach($rows as $key=>$value)
          {
              $temp = [];
              $temp['id']=$value->id;
              $temp['first_name'] = $value->employee->first_name;
              $temp['date'] = $value->date;
              $temp['start'] = $value->start;
              $temp['end'] = $value->end;
              $temp['status'] = $value->status;
              $final[]=$temp;
          }
          $timesheets['rows'] = sortArray($final, $request);
          return view('supervisors.pendingTimesheet', $timesheets);
    }

    public function approveRequest(Request $request){

        if($request->action == 1){

            $approve = Timesheet::where('id',$request->id)->first();
            $approve->status = 1;
            $approve->save();

            $supervisor = $this->supervisor->getSupervisorId(Auth::id());

            $activity = new Activity;
            $activity->user_id = $supervisor->user_id;
            $activity->message = "supervisor has approved timesheet request";
            $activity->save();

            sendEmail($approve->user_id,EMP_JOBSITE_APPR);
        }
        if($request->delete == 1){

            $approve = Timesheet::where('id',$request->id)->first();
            
            $activity = new Activity;
            $activity->user_id = $approve->employee_id;
            $activity->message = "supervisor has removed timesheet request";
            $activity->save();

            $approve->delete();

        }
        return redirect()->action('SupervisorController@sup_pending_req');

    }

}
