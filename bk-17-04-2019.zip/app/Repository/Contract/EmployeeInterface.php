<?php

namespace App\Repository\Contract;

use App\Repository\Contract\BaseInterface as BaseInterface;

interface EmployeeInterface extends BaseInterface{
}