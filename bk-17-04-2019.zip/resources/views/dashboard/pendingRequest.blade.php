@extends('layouts.dore.app')

@section('content')
<div class="page-header">
	<div class="row">
		<div class="col-lg-12">
			<h1>Jobsite List</h1>
			<hr/>
		</div>
	</div>
	
    <div class="white_bg_main">
  
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
			<table class="table table-hover table-bordered">
				<thead class="thead-dark">
					<tr>
						<th scope="col" class="" width="10%">#</th>
						<th scope="col" class="">Username</th>
						<th scope="col" class="">Company</th>
						<th scope="col" class="">Jobsite</th>
						<th scope="col" class="">Position</th>
						<th scope="col" class="">Status</th>
						<th scope="col" class="text-center" width="15%">Approve</th>
                        <th scope="col" class="text-center" width="15%">Delete</th>
					</tr>
				</thead>
			  	<tbody>
			  		@foreach($data as $row)
			  		<tr>
			  			<td class="">{{ $row->id }}</td>
			  			<td class="">{{ $row->user->username }}</td>
			  			<td class="">{{ $row->client->company_name }}</td>
			  			<td class="">{{ $row->jobsite->title }}</td>
			  			<td class="">
                            @if($row->position != '')
                                {{ $row->position->title }}
                            @endif
                        </td>
			  			<td class="">
                                   <?php if($row->status==0){
                                           echo "&#10006;";
                                   }
                                   else{
                                           echo "Approved";
                                   }?>
                                   </td>
			  			<td class="text-center">

                            @if($row->status==0)
    			  				<form method="POST" action="{{ url('/requests/') }}">
    			  					{{ csrf_field() }}
    			  					<input type="hidden" name="id" value="{{$row->id}}">
                                    <input type="hidden" name="action" value="1">
    			  					<button type="submit" class="btn btnbg">approve</button>
    			  				</form>
                            @endif
							
						</td>
                        <td class="text-center">
                            <form method="POST" action="{{ url('/requests/') }}">
                                {{ csrf_field() }}
                                <input type="hidden" name="id" value="{{$row->id}}">
                                <input type="hidden" name="action" value="2">
                                <button type="submit" class="btn btnbg">delete</button>
                            </form>
                        </td>
		  			</tr>
		  			@endforeach
			  	</tbody>
		  	</table>
		  </div>
		</div>
	</div>
	
	
</div>
</div>
@endsection