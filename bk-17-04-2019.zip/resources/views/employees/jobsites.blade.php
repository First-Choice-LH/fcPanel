@extends('layouts.dore.app')

@section('content')
<div class="page-header">
	<div class="row">
		<div class="col-lg-12">
			<h1>Jobsite List</h1>
			<hr/>
		</div>
	</div>
	
    <div class="white_bg_main">
    @if(isset($rows) && count($rows)>0)
    	<div class="row">
    		<div class="col-lg-12">
    			<div class="table-responsive">
    			<table class="table table-hover table-bordered sortable_table">
    				<thead class="thead-dark">
    					<tr>
    						<th scope="col" class="" width="10%">#</th>
    						<th scope="col" class="" data-col="title">Title</th>
    						<th scope="col" class="" data-col="company_name">Company</th>
    						<th scope="col" class="text-center" width="15%">&nbsp;</th>
    					</tr>
    				</thead>
    			  	<tbody>
    			  		 @foreach($rows as $row)
    			  		<tr>
    			  			<td class="">{{ $row['id'] }}</td>
    			  			<td class="">{{ $row['title'] }}</td>
    			  			<td class="">{{ $row['company_name'] }}</td>
    			  			<td class="text-center">
    							<a class="btn btnbg" href="{{ url('/employees/jobsites/timesheet/'.$row['id'].'/'.$row['client_id']) }}">Timesheet</a>
    						</td>
    		  			</tr>
    		  			@endforeach
    			  	</tbody>
    		  	</table>
    		  </div>
    		</div>
    	</div>
    @else
        <div class="row">
            <div class="col-md-12">
                <h3>{{'There are no jobsites or companies assigned to your account yet.'}}</h3>
            </div>
            
            
                <div class="col-md-4"><a class="btn btnbg btn-primary" href="/employee/jobsites/request">{{ __('REQUEST JOBSITE') }}</a></div>
                
            </div>
        </div>
    @endif
</div>
</div>
@endsection

@section('script')
<script type="text/javascript">
    
</script>
@endsection