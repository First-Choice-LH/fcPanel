<!DOCTYPE html>
<html>
    <head>
        <title>Jobsite Approved</title>
    </head>
    <body>
        <h2>Your jobsite has been approved</h2>
    </body>
</html>