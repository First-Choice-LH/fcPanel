@extends('layouts.dore.app')

@section('content')
<div class="page-header">
	<div class="row">
		<div class="col-lg-12">
			<h1>Employee List</h1>
			<hr/>
		</div>
	</div>
	<div class="white_bg_main">
        <div class="row">
                <form metod="get" action="{{ url('employees') }}">
                    <!-- <div class="row">
                        <div class="form-group col-lg-6">
                            <input type="text" class="form-control" name="q" value="{{ \Request::get('q') }}"/>
                        </div>
                        <div class="form-group col-lg-6">
                            <a href="" class="btn btnbg btnbig"> Search </a>
                        </div>
                    </div> -->
                </form>
            <div class="col-lg-12 table-responsive">
                <table class="table table-hover sortable_table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col" class="text-center" width="10%">#</th>
                            <th scope="col" class="text-center" data-col="first_name">First Name</th>
                            <th scope="col" class="text-center" data-col="last_name">Last Name</th>
                            <th scope="col" class="text-center" data-col="phone">Phone</th>
                             <th scope="col" class="text-center" data-col="jobsite">JobSite Title</th>
                        </tr>
                    </thead>
                   	<tbody>
                       
                        @foreach($rows as $row)
                        <tr>
                            <td class="text-center">{{ $row['id'] }}</td>
                            <td class="text-center">{{ $row['first_name'] }}</td>
                            <td class="text-center">{{ $row['last_name'] }}</td>
                            <td class="text-center">{{ $row['phone'] }}</td>
                            <td class="text-center">{{ $row['jobsite'] }}</td>
                        </tr>
                        @endforeach
                    </tbody>
		  	    </table>
                	 {{ $rows->appends(request()->except('page'))->links() }}
            </div>
        </div>
    </div>
</div>

@endsection