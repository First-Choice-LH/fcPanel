@extends('layouts.dore.app')

@section('content')
<div class="page-header">
	<div class="row">
		<div class="col-lg-12">
			<h1>TimeSheets List</h1>
			<hr/>
		</div>
	</div>
    <div class="white_bg_main">
	<div class="row">
		<div class="col-lg-12">
            <form class="row" method="get" action="">
               <div class="col-lg-3 form-group">
                   <label class="">Employee</label>
                   <input class="form-control" type="text" id="employee" value="">
               </div>
               <div class="col-lg-1 form-group text-center">
                   <label style="color:transparent;">Action</label>
                   <button type="button" class="btn btnbg btnbig search">Fetch</button>
               </div>
           </form>
       </div>
       <div class="col-lg-6"></div>
	</div>
	
	<div class="row">
		<div class="col-lg-12 table-responsive">
        <table class="table table-hover table-bordered sortable_table">
                        <thead class="thead-dark">
                        <tr>
                            <th scope="col" class="d-none d-md-table-cell" width="10%">#</th>
                            <th scope="col" class="" data-col="first_name">Employee</th>
                            <th scope="col" class="" data-col="date">Date</th>
                            <th scope="col" class="d-none d-md-table-cell" data-col="start">Start</th>
                            <th scope="col" class="d-none d-md-table-cell" data-col="end">End</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($rows as $row)
                        <tr>
                            <td scope="row" class="d-none d-md-table-cell">{{ $row['id'] }}</td>
                            <td scope="row" class="">{{ $row['first_name'] }}</td>
                            <td scope="row" class="">{{ $row['date'] }}</td>
                            <td scope="row" class="d-none d-md-table-cell">{{ date("h:i A", strtotime($row['start'])) }}</td>
                            <td scope="row" class="d-none d-md-table-cell">{{ date("h:i A", strtotime($row['end'])) }}</td>                            
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                    {{ $rows->appends(request()->except('page'))->links() }}
		</div>
	</div>
</div>

@endsection

@section('script')
<script type="text/javascript">
   $('.search').click(function(){
       var employee = $('#employee').val();
       var url = "{{ url('/supervisors/timesheets') }}";
       url = url+"?employee="+employee;
       document.location = url;
   });
</script>
@endsection